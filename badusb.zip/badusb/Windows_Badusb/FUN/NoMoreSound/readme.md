
# NoMoreSound
Mutes the windows audio.

## How to use?

This script is plug and play.


## Features

- open powershell
- mute windows audio


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


