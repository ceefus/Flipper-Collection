
# StealWifiKeys_Email
Steals all of the saved Wifi Passwords and stores them into a file, then sends the file via email.

## How to use?

This script is not plug and play and only for experienced users. You will need to do the following changes:

- change credentials "System.Net.NetworkCredential('EMAIL HERE', 'EMAIL PASSWORD HERE')"
- change credentails "$ReportEmail.From = 'YOUR EMAIL'"
- change credentials "$ReportEmail.To.Add('email to send to')"


## Features

- open powershell
- grab wifi keys
- store keys to a file
- send file via email

## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


