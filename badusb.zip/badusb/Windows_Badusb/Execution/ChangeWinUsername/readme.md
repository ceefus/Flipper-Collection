
# ChangeWinUsername

This script simply changes the Windows Username.




## How to use?

This script is not plug and play. You need to replace "New Name" to any name you want right here: "STRING Rename-LocalUser -Name $User -NewName "New Name""




## Features

- open powershell
- change windows username




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


