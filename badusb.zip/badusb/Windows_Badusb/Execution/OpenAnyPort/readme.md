
# OpenAnyPort

This script adds a firewall rule to the Windows Advanced Firewall that allows incoming traffic over TCP or UDP on a specific port number.



## How to use?

This script is not plug and play. You will have to do the following changes:

- choose protocol "protocol=TCP or UDP"
- change localport "localport=Port Number"
- choose entry name "name=Firewall entry name"


## Features

- open powershell 
- create new entry
- allow port to receive traffic





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


