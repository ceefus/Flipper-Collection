
# Create_New_Windows_Admin

This script creates a new windows admin user on the target pc.




## How to use?

This script is plug and play. After the new user is created you need to use the username "root" and the password "toor" to login.




## Features

- open powershell
- create new admin user
- create name "root"
- create password "toor"




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


