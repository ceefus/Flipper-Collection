
# ListWindowsUpdates
This script is going to save the names of installed windows updates.

## How to use?

This script is not plug and play. You need to do the following changes:

- change path for the file "-DestinationPath results-90412137.zip"


## Features

- open powershell 
- list windows updates
- store them into a file



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


