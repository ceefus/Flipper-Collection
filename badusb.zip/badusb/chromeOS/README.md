<h2><strong>ABOUT</strong></h2>

Alot of the chromeOS scripts I found were actually pretty shit and just transfered from other existing windowsOS and macOS scripts.
So I made my own and please enjoy.

Please note: this might not work on all chromeOS or chromebook devices and change the script to fit your chromebook, but it should work on most chromebooks out there.
