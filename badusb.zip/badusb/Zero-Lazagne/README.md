# Zero-Lazagne
Bad Usb payload capable to capture victim's passwords (hiding powershell) and e-mailing them to you. Inspired by "Hasta Lasagna!", developed by [m4ki3lf0](https://github.com/hak5/usbrubberducky-payloads/tree/master/payloads/library/credentials/Hasta%20lasagna!) for Rubber Ducky, and optimized for Flipper Zero. You'll need only the .txt file for the exfiltration.  
## Notes
Tested with Unleashed Firmware and a SMTP without SSL (port 25) to send the e-mail. The 2.4.2 version of lazagne.exe is a bit faster, anyway it's possibile to replace the download link with the latest version.
