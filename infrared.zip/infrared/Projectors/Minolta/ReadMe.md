


### Minolta MN674 ###

<img align="right" width="200" height="200" src="Minolta-MN674.jpg">

Brand Name: Minolta
Model: MN674

This is a rebranded C500 Projector with minor firmware changes

URL: https://www.amazon.com/Minolta-MN674/dp/B08WZ3DNL2


